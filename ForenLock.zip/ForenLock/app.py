from flask import Flask, render_template, request, redirect, session, flash, send_from_directory
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
import face_recognition
import numpy as np
import pickle
import hashlib
import base64
from io import BytesIO
from PIL import Image
import os
import uuid
import shutil

app = Flask(__name__)
app.secret_key = "forenlock_secret_key_123"

app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'forenlock_user'
app.config['MYSQL_PASSWORD'] = 'forenlock123'
app.config['MYSQL_DB'] = 'forenlock_db'

mysql = MySQL(app)

BASE_UPLOAD_FOLDER = 'uploads'
os.makedirs(BASE_UPLOAD_FOLDER, exist_ok=True)

FREE_STORAGE_LIMIT = 2 * 1024 * 1024 * 1024  # 2GB


# ==============================
# HELPER FUNCTIONS
# ==============================

def generate_hash(file_path):
    with open(file_path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def get_user_folder(user_id):
    folder = os.path.join(BASE_UPLOAD_FOLDER, f"user_{user_id}")
    os.makedirs(folder, exist_ok=True)
    return folder


def get_user_storage_used(user_id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT IFNULL(SUM(file_size),0) FROM evidence WHERE user_id=%s", (user_id,))
    total = cur.fetchone()[0]
    cur.close()
    return total or 0


# ==============================
# ROOT
# ==============================

@app.route('/')
def root():
    return redirect('/login')


# ==============================
# SIGNUP
# ==============================

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':

        name = request.form['name']
        email = request.form['email']
        raw_password = request.form['password']

        if len(raw_password) < 8:
            flash("Password must be at least 8 characters long.", "error")
            return redirect('/signup')

        cur = mysql.connection.cursor()

        cur.execute("SELECT user_id FROM users WHERE email=%s", (email,))
        if cur.fetchone():
            cur.close()
            flash("Email already registered.", "error")
            return redirect('/signup')

        cur.execute("SELECT COUNT(*) FROM users")
        user_count = cur.fetchone()[0]
        role = "admin" if user_count == 0 else "user"

        password = generate_password_hash(raw_password)

        cur.execute("""
            INSERT INTO users (name, email, password_hash, role)
            VALUES (%s, %s, %s, %s)
        """, (name, email, password, role))

        mysql.connection.commit()
        user_id = cur.lastrowid
        cur.close()

        session['temp_user_id'] = user_id
        return redirect('/face_register')

    return render_template('signup.html')


# ==============================
# LOGIN
# ==============================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':

        email = request.form['email']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT user_id, password_hash FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close()

        if user and check_password_hash(user[1], password):
            session.pop('_flashes', None)
            session['verify_user_id'] = user[0]
            return redirect('/face_verify')

        flash("Invalid email or password.", "error")
        return redirect('/login')
 
    return render_template('login.html')


# ==============================
# FACE REGISTER
# ==============================

@app.route('/face_register', methods=['GET', 'POST'])
def face_register():
    if 'temp_user_id' not in session:
        return redirect('/login')

    if request.method == 'POST':

        image_data = request.form['image'].split(",")[1]
        image_bytes = base64.b64decode(image_data)

        image = Image.open(BytesIO(image_bytes)).convert("RGB")
        image = np.array(image, dtype=np.uint8)

        locations = face_recognition.face_locations(image, model="hog")
        encodings = face_recognition.face_encodings(image, locations)

        if not encodings:
            flash("No face detected. Try again.", "error")
            return redirect('/face_register')

        face_encoding = pickle.dumps(encodings[0])

        cur = mysql.connection.cursor()
        cur.execute("UPDATE users SET face_encoding=%s WHERE user_id=%s",
                    (face_encoding, session['temp_user_id']))
        mysql.connection.commit()
        cur.close()

        session.pop('temp_user_id', None)
        flash("Face registered successfully!", "success")
        return redirect('/login')

    return render_template('face_register.html')


# ==============================
# FACE VERIFY
# ==============================

@app.route('/face_verify', methods=['GET', 'POST'])
def face_verify():
    if 'verify_user_id' not in session:
        return redirect('/login')

    if request.method == 'POST':

        image_data = request.form['image'].split(",")[1]
        image_bytes = base64.b64decode(image_data)

        image = Image.open(BytesIO(image_bytes)).convert("RGB")
        image = np.array(image, dtype=np.uint8)

        locations = face_recognition.face_locations(image, model="hog")
        encodings = face_recognition.face_encodings(image, locations)

        if not encodings:
            flash("No face detected.", "error")
            return redirect('/face_verify')

        input_encoding = encodings[0]

        cur = mysql.connection.cursor()
        cur.execute("SELECT face_encoding FROM users WHERE user_id=%s",
                    (session['verify_user_id'],))
        result = cur.fetchone()
        cur.close()

        if not result or not result[0]:
            flash("Face not registered.", "error")
            return redirect('/login')

        stored_encoding = pickle.loads(result[0])
        distance = face_recognition.face_distance([stored_encoding], input_encoding)[0]

        if distance < 0.45:
            session['user_id'] = session['verify_user_id']
            session.pop('verify_user_id', None)
            return redirect('/home')
        else:
            flash("Face does not match.", "error")
            return redirect('/login')

    return render_template('face_verify.html')


# ==============================
# HOME
# ==============================

@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()
    cur.execute("SELECT role FROM users WHERE user_id=%s", (session['user_id'],))
    result = cur.fetchone()
    role = result[0] if result else "user"
    cur.close()

    return render_template('home.html', role=role)


# ==============================
# UPLOAD
# ==============================

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'user_id' not in session:
        return redirect('/login')

    if request.method == 'POST':

        file = request.files['evidence_file']
        current_usage = get_user_storage_used(session['user_id'])

        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)

        if current_usage + file_size > FREE_STORAGE_LIMIT:
            flash("Storage limit exceeded (2GB Free Plan)", "error")
            return redirect('/upload')

        user_folder = get_user_folder(session['user_id'])
        unique_name = str(uuid.uuid4()) + "_" + file.filename
        path = os.path.join(user_folder, unique_name)
        file.save(path)

        file_hash = generate_hash(path)

        cur = mysql.connection.cursor()

        cur.execute("""
        INSERT INTO evidence (filename, file_path, original_hash, status, user_id, file_size)
        VALUES (%s, %s, %s, 'SAFE', %s, %s)
        """, (file.filename, path, file_hash, session['user_id'], file_size))

        evidence_id = cur.lastrowid 

        cur.execute("""
        INSERT INTO forensic_timeline (user_id, evidence_id, action)
        VALUES (%s, %s, %s)
        """, (session['user_id'], evidence_id, "File Uploaded"))

        mysql.connection.commit()  
        cur.close()                
        return redirect('/upload')

    return render_template('upload.html')


# ==============================
# DASHBOARD
# ==============================

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()
    cur.execute("SELECT evidence_id, filename, status FROM evidence WHERE user_id=%s",
                (session['user_id'],))
    files = cur.fetchall()
    cur.close()

    return render_template('dashboard.html', files=files)


# ==============================
# MY FILES (ADDED BACK)
# ==============================

@app.route('/my_files')
def my_files():
    if 'user_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()

    cur.execute("SELECT evidence_id, filename, status FROM evidence WHERE user_id=%s",
                (session['user_id'],))
    files = cur.fetchall()

    cur.execute("SELECT IFNULL(SUM(file_size), 0) FROM evidence WHERE user_id=%s",
                (session['user_id'],))
    storage_used = cur.fetchone()[0]

    cur.close()

    return render_template('my_files.html',
                           files=files,
                           storage_used=storage_used)

# ==============================
# TIMELINE
# ==============================

@app.route('/timeline_all')
def timeline_all():
    if 'user_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT action, timestamp
        FROM forensic_timeline
        WHERE user_id=%s
        ORDER BY timestamp DESC
    """, (session['user_id'],))

    events = cur.fetchall()
    cur.close()

    return render_template('timeline_all.html', events=events)

# ==============================
# DOWNLOAD
# ==============================

@app.route('/download/<int:file_id>')
def download_file(file_id):
    if 'user_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()
    cur.execute("SELECT file_path FROM evidence WHERE evidence_id=%s AND user_id=%s",
                (file_id, session['user_id']))
    file = cur.fetchone()
    cur.close()
    cur = mysql.connection.cursor()
    cur.execute("""
    INSERT INTO forensic_timeline (user_id, evidence_id, action)
    VALUES (%s, %s, %s)
    """, (session['user_id'], file_id, "File Downloaded"))
    mysql.connection.commit()
    cur.close()
    if file:
        return send_from_directory(os.path.dirname(file[0]),
                                   os.path.basename(file[0]),
                                   as_attachment=True)

    return "Unauthorized"


# ==============================
# ADMIN PANEL
# ==============================

@app.route('/admin')
def admin():
    if 'user_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()
    cur.execute("SELECT role FROM users WHERE user_id=%s", (session['user_id'],))
    role = cur.fetchone()[0]

    if role != "admin":
        cur.close()
        return "Access Denied"

    cur.execute("SELECT COUNT(*) FROM users")
    total_users = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM evidence")
    total_files = cur.fetchone()[0]

    cur.execute("""
        SELECT u.user_id, u.name, u.email, u.role,
               IFNULL(SUM(e.file_size), 0)
        FROM users u
        LEFT JOIN evidence e ON u.user_id = e.user_id
        GROUP BY u.user_id
    """)
    users_data = cur.fetchall()
    cur.close()

    users = []
    FREE_LIMIT = 2 * 1024 * 1024 * 1024  # 2GB

    for u in users_data:
        users.append({
            "id": u[0],
            "name": u[1],
            "email": u[2],
            "role": u[3],
            "storage_used": u[4],
            "percent": (u[4] / FREE_LIMIT) * 100 if u[4] else 0
        })

    return render_template("admin.html",
                           total_users=total_users,
                           total_files=total_files,
                           users=users)

# ==========================================
# DELETE USER
# ==========================================

@app.route('/delete_user/<int:user_id>')
def delete_user(user_id):
    if 'user_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()

    cur.execute("SELECT role FROM users WHERE user_id=%s", (session['user_id'],))
    role = cur.fetchone()[0]

    if role != "admin":
        cur.close()
        return "Access Denied"

    cur.execute("DELETE FROM evidence WHERE user_id=%s", (user_id,))

    cur.execute("DELETE FROM users WHERE user_id=%s", (user_id,))

    mysql.connection.commit()
    cur.close()

    flash("User deleted successfully!", "success")
    return redirect('/admin')

# ==============================
# LOGOUT
# ==============================

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')


if __name__ == '__main__':
    app.run(debug=True)